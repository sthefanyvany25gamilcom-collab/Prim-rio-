// Caça-Estrelas — lógica simples do jogo
const GAME_DURATION = 30;
const scoreEl = document.querySelector("#score");
const timeEl = document.querySelector("#time");
const bestEl = document.querySelector("#best");
const progressEl = document.querySelector("#progress");
const playfield = document.querySelector("#playfield");
const welcome = document.querySelector("#welcome");
const target = document.querySelector("#target");
const result = document.querySelector("#result");
const resultTitle = document.querySelector("#resultTitle");
const resultText = document.querySelector("#resultText");
const startBtn = document.querySelector("#startBtn");
const againBtn = document.querySelector("#againBtn");

let score = 0;
let timeLeft = GAME_DURATION;
let timerId = null;
let playing = false;
let best = Number(localStorage.getItem("cacaEstrelasRecorde") || 0);

bestEl.textContent = formatScore(best);

function formatScore(value) {
  return String(value).padStart(2, "0");
}

function startGame() {
  clearInterval(timerId);
  score = 0;
  timeLeft = GAME_DURATION;
  playing = true;
  scoreEl.textContent = formatScore(score);
  timeEl.innerHTML = `${timeLeft}<span class="seconds">s</span>`;
  progressEl.style.width = "100%";
  welcome.hidden = true;
  result.hidden = true;
  target.hidden = false;
  moveTarget();
  timerId = setInterval(() => {
    timeLeft -= 1;
    timeEl.innerHTML = `${timeLeft}<span class="seconds">s</span>`;
    progressEl.style.width = `${(timeLeft / GAME_DURATION) * 100}%`;
    if (timeLeft <= 0) endGame();
  }, 1000);
}

function moveTarget() {
  const fieldRect = playfield.getBoundingClientRect();
  const size = 50;
  const maxX = Math.max(0, fieldRect.width - size - 12);
  const maxY = Math.max(0, fieldRect.height - size - 12);
  target.style.left = `${Math.random() * maxX + 6}px`;
  target.style.top = `${Math.random() * maxY + 6}px`;
  const special = Math.random() < 0.2;
  target.classList.toggle("special", special);
  target.textContent = special ? "✧" : "✦";
  target.dataset.points = special ? "3" : "1";
  target.setAttribute("aria-label", special ? "Pegar estrela especial, vale 3 pontos" : "Pegar estrela, vale 1 ponto");
}

function collectStar() {
  if (!playing) return;
  score += Number(target.dataset.points || 1);
  scoreEl.textContent = formatScore(score);
  moveTarget();
}

function endGame() {
  playing = false;
  clearInterval(timerId);
  target.hidden = true;
  result.hidden = false;
  const isNewRecord = score > best;
  if (isNewRecord) {
    best = score;
    localStorage.setItem("cacaEstrelasRecorde", String(best));
    bestEl.textContent = formatScore(best);
  }
  resultTitle.textContent = isNewRecord ? "Novo recorde! 🎉" : score >= 20 ? "Você brilhou muito!" : "Mandou bem!";
  resultText.textContent = `Você fez ${score} ${score === 1 ? "ponto" : "pontos"} em 30 segundos.`;
}

startBtn.addEventListener("click", startGame);
againBtn.addEventListener("click", startGame);
target.addEventListener("click", collectStar);
